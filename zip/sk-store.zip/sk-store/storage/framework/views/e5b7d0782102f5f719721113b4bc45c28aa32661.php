<div>
    <a class="dropdown-item" wire:click="logout" style="cursor: pointer"><i class="fa fa-sign-out-alt"></i> LOGOUT</a>
</div>
<?php /**PATH /Users/maulayyacyber/LaravelProject/sk-store/resources/views/livewire/customer/auth/logout.blade.php ENDPATH**/ ?>