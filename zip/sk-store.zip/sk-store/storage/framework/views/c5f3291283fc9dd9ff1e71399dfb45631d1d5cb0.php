<?php $__env->startSection($section); ?>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount($component, $componentParameters)->dom;
} elseif ($_instance->childHasBeenRendered('G8WBgcS')) {
    $componentId = $_instance->getRenderedChildComponentId('G8WBgcS');
    $componentTag = $_instance->getRenderedChildComponentTagName('G8WBgcS');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('G8WBgcS');
} else {
    $response = \Livewire\Livewire::mount($component, $componentParameters);
    $dom = $response->dom;
    $_instance->logRenderedChild('G8WBgcS', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maulayyacyber/LaravelProject/sk-store/vendor/livewire/livewire/src/Macros/livewire-view.blade.php ENDPATH**/ ?>