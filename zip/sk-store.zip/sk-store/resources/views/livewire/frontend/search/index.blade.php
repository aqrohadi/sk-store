<div class="mx-2 my-auto d-inline" style="width: 45%">
    <div class="input-group">
        <input type="text" wire:model="search" class="form-control border border-right-0" placeholder="Search...">
        <span class="input-group-append">
            <button class="btn text-dark border border-left-0" style="background-color: white" type="button">
                <i class="fa fa-search"></i>
            </button>
        </span>
    </div>
</div>
