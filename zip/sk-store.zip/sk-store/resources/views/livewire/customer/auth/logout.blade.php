<div>
    <a class="dropdown-item" wire:click="logout" style="cursor: pointer"><i class="fa fa-sign-out-alt"></i> LOGOUT</a>
</div>
