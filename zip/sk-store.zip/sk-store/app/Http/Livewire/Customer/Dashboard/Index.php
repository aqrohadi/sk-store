<?php

namespace App\Http\Livewire\Customer\Dashboard;

use Livewire\Component;

class Index extends Component
{
    public function render()
    {
        return view('livewire.customer.dashboard.index');
    }
}
